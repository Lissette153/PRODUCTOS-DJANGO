from django.shortcuts import render

def index(request):
    return render(request,'tiendaTemplate/index.html')

def categoria(request, categoria):

    if categoria == "electronica":
        data= [
            {'nombre': 'Mouse Gamer', 'descripcion': 'Antideslizante, mayor fuerza de clicks y buen superficie de agarre', 'imagen': 'images/mouse.jpg'},
            {'nombre': 'Tarjeta SSD', 'descripcion': '1 TB de almacenimiento', 'imagen': 'images/SSD.jpg'},
            {'nombre': 'Gabinete GAMER', 'descripcion': 'La mejor expansion de espacio para poder construir tu setup gamer', 'imagen': 'images/gabinete.jpg'}
        ]
    elif categoria == 'juguetes':
        data= [
            {'nombre': 'Rayo McQueen', 'descripcion': 'Igual de veloz como en la pelicula. Kuchau', 'imagen': 'images/rayo.png'},
            {'nombre': 'Play doh', 'descripcion': 'La mejor masa para poder volar tu imaginacion', 'imagen': 'images/playdo.png'},
            {'nombre': 'Terreneitor', 'descripcion': 'El coche más poderoso que ah existido, con tracción 4X4 y dos TURBO motores! Este si es todo terreno, las calles son fáciles, Mételo al lodo, parte la nieve, pasa por el agua ! TERRENEITOR!', 'imagen': 'images/terreneitor.png'}
        ]
    elif categoria == 'ropa':
        data=[
            {'nombre': 'Poleron nike unisex', 'descripcion': 'Ya sea para lucir un look casual y deportivo o para mantenerte abrigado durante tus actividades al aire libre, la sudadera unisex Nike es una elección versátil que combina moda y funcionalidad en una sola prenda. Con su calidad, diseño atemporal y reconocimiento global, es una pieza esencial en el guardarropa de cualquier persona amante de la moda y el deporte.', 'imagen': 'images/nike.jpg'},
            {'nombre': 'Sweater Mujer', 'descripcion': 'Un sweater para mujer es una prenda esencial que combina comodidad, estilo y versatilidad. Ya sea para lucir un look casual y relajado o para elevar tu estilo en ocasiones más formales, un buen sweater es una inversión valiosa en tu guardarropa.', 'imagen': 'images/sweater.jpg'},
            {'nombre': 'Jeans basico unisex', 'descripcion': 'Los jeans básicos unisex son una prenda esencial que combina funcionalidad y estilo atemporal. Su diseño versátil, corte cómodo y durabilidad los convierten en una elección popular para uso diario, adaptándose a una amplia variedad de estilos y ocasiones.', 'imagen': 'images/jeans.png'}
        ]
        
    contexto = {
        'categoria': categoria,
        'data': data,
    }

    return render(request, 'tiendaTemplate/productos.html', contexto)